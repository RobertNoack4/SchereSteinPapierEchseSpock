<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class plgSystemdjimgtowebpInstallerScript
{

    function preflight($type, $parent)
    {
        $db = JFactory::getDbo();

        $query = $db->getQuery(true);
        $query->select(array(
            'e.manifest_cache',
            'e.params',
            'e.extension_id'
        ));
        $query->from('#__extensions AS e');
        $query->where('e.element = ' . $db->quote('djimgtowebp'));
        $query->where('e.type = ' . $db->quote('plugin'));
        $db->setQuery($query);


        $schema = $db->loadObject();
        if (isset($schema->manifest_cache)) {
            $manifest = json_decode($schema->manifest_cache);

            if (version_compare($manifest->version, '1.0-dev','<')) {
                $params = json_decode($schema->params);
                $newFilters = array();

                if (isset($params->filters)) {
                    $filters = json_decode($params->filters);
                    $filtersCount = count((array)$filters->directory);
                    if ($filtersCount) {
                        $index = 10;
                        for ($x = 0; $x < $filtersCount; $x++) {
                            $newFilters['__field' . $index] = array(
                                'directory' => $filters->directory[$x],
                                'extensions' => $filters->extensions[$x],
                                'quality' => $filters->quality[$x],
                                'stored_time' => $filters->stored_time[$x],
                                'excluded' => $filters->excluded[$x]
                            );
                            $index++;
                        }

                    }

                    $params->filters = json_encode($newFilters);
                    $paramsJson = json_encode($params);
                    $db->setQuery('UPDATE #__extensions SET params = ' . $db->quote($paramsJson) . ' WHERE extension_id = ' . $schema->extension_id);
                    if ($db->execute()) {
                        return true;
                    } else {
                        $app = JFactory::getApplication();
                        $app->enqueueMessage(JText::_('PLG_SYSTEM_DJIMGTOWEBP_FAILED_UPDATE_PARAMS'), 'error');
                        return false;
                    }


                }
            }
        }
    }


}